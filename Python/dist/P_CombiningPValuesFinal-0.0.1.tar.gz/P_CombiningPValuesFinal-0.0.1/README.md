# Master2021

Thesis repo contains the Python and R code created by Breya McGlown under the guidance of Dr. Ebenzer George.

Both languages provide the end user the opportunity to utilize six fundamental statistics used for combination of p-values, typically used duing Meta-analyses.

To Use: 

    Python: update readme to include the order of functions to use 
    
    R: update readme to include the order of functions to use 
    
    

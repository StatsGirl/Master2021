# P_CombiningPValuesFinal

This is a new release of 0.1.4 P_CombiningPValuesFinal. New additions include new functionality 
that returns the combined p value of the test statistic selected.
Updates to Tippett and George Method. Also InfinitePs in no SumOfPs
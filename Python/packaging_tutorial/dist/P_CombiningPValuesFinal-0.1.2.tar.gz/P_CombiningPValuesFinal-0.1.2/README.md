# P_CombiningPValuesFinal

This is a new release of 0.0.1 P_CombiningPValuesFinal. New additions include new functionality 
that returns the combined p value of the test statistic selected.
library(testthat)
library(combinationpvalues)

test_check("combinationpvalues")

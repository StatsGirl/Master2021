combinationpvalues (0.1.0)
     Initial version
combinationpvalues (0.1.2)
    CombinedPValueMethod added
